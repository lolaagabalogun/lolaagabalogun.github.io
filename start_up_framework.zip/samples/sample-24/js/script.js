
$(window).resize(function() {
    var sH = $(window).height();
    $('section.header-14-sub').css('height', sH + 'px');
});